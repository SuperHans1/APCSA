import java.util.Scanner;

public class Main {
  public static void main(String[] args) {
    Scanner scan = new Scanner(System.in);
    System.out.println("\n\n You are stuck in the middle of the Atlantic Ocean. Your compass points you to go south for South America, west for North America, north for Europe, and east for Africa. Which way will you direct your ship (n,e,s,w?");
    String command = scan.nextLine();
    if (command.equals("n")) 
    {
        System.out.println("You have arrived at a harbor in the United Kingdom. You see a map that gives you directions to go north to London, east to Cambridge, south to Liverpool, or west to Manchester. Which city do you want to visit first?(n,e,s,w)");

        command = scan.nextLine();
         if (command.equals("n"))
         {
          System. out.println("You have arrived to London and choose to go on a shopping spree. You have spent all your money and are now broke. Game over.");
          command = scan.nextLine();
        }
        if (command.equals("e")){
          System.out.println("You have arrived at Cambridge and you're now going to study there for the next 4 years. Game over.");
          command = scan.nextLine();
        }
        if (command.equals("s")){
          System.out.println("You have arrived at Liverpool. You ate a poisoned pie. Game over.");
        }
    }
    
     
     else if (command.equals("s"))
      {
          System.out.println("You have made it to  South America, enjoy the beaches and the weather. Try not to get bit by a shark. Game Over");
          }
  
    else if (command.equals("w")) 
    {
        System.out.println("You have arrived at a harbor in the North America. Pick  n,e,w,s to go somewhere in North America;");
        command = scan.nextLine();
          
      if(command.equals("n"))
      {
      System.out.print("You made it to Boston,Press y to replay");
      
      }
      else if(command.equals("e"))
      {
      System.out.print("You made it to Kansas, Game over.");
      command = scan.nextLine();
      }
      
      else if(command.equals("w"))
      {
      System.out.print("You made it to Chicago, Game over");
      command = scan.nextLine();
      }
      else if(command.equals("s"))
      {
      System.out.print("You made it to  Florida game over");
      command = scan.nextLine();
      }
    }
    else if (command.equals("e")) 
    {
        System.out.println("You have arrived at Africa. You have decided to live here for the next 5 years to study African culture and society. Game over.");
    } 
    // Add else-ifs for s, e, and an else for any other input. Be creative!
    
    
    // System.out.println("End of adventure!");   
    scan.close();
  }
}
import java.util.Scanner; 

class Main {
  public static void main(String[] args) {
    String[] words = {"frame", "honor", "learn", "tiger", "watch","zebra","light","humor", "jumpy", "glent", "brick", "vases","india"};
    int index = (int)(Math.random() * words.length);
    System.out.println("Welcome to Wordle! You have a total of 6 guess to guess the 5 lettered hidden word!");
    HiddenWord word = new HiddenWord(words[index]);
    Scanner guess = new Scanner(System.in);
    int count = 0;
    while (count < 6){
      String guessWord = guess.next();
      String hint = word.getHint(guessWord);
      if (hint.equals(guessWord)){
        System.out.println("Hurray!");
        count = 6;
      }
      else{
        System.out.println(hint);
        count++;
        System.out.println("You have used " + count + "/6 guesses.");

          if(count==6){
            System.out.println("You lost!");
            System.out.println("The word was " + word.getWord() + ".");
          }
      } 
    }
  }
}